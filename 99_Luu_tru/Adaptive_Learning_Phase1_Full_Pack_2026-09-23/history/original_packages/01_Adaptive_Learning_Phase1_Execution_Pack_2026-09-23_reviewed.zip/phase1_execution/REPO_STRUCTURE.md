# Repository / Module Structure Proposal

This is a **proposal for a missing/uninspected repository**, not evidence that directories exist. Adopt existing repo conventions first and align with exact V3.2.

```text
repo/
  apps/
    learner_flutter/              # Android-first, iOS-supportable
    staff_flutter_web/            # administrative shell
  backend/
    app/
      api/                       # FastAPI composition, transport adapters
      modules/
        identity/ content/ learning/ assessment/
        recommendation/ analytics/ engagement/
      shared/                    # transaction, IDs, clock, config, logging
      worker/                    # durable processor process, same codebase
    migrations/                  # canonical, ordered migration tool
    tests/
      contract/ integration/ concurrency/ security/
  contracts/                    # original V3.2 files/reference, not invented copies
  docs/                         # product/architecture/change records
  infra/dev/                    # local database/storage only
  .github/workflows/            # or existing CI provider
```

Module boundaries: API is input validation and orchestration; domain/application services own canonical transactions; adapters own PostgreSQL/object storage; worker consumes durable work idempotently. Command mutations are distinct from best-effort telemetry ingestion. Content publication and attempts pin revisions. Analytics projection cannot leak observations known only after a historical decision. Mastery, risk and recommendation remain separate modules/concepts. No Kafka, K8s, microservices or warehouse absent measured requirement.

Acceptance when repository is supplied: module ownership map cites actual paths; no duplicate source of truth; API and worker independently boot from same codebase; frontends compile; one V3.2 reference identifies each exact contract.
