# Project Memory — current accepted state

Updated 2026-09-23 after owner review. This file is a durable project handoff record, not a claim that platform-level ChatGPT memory or the original V3.2 contract has been changed.

## Source precedence

Current explicit owner instruction → exact approved V3.2 source → approved CR/latest owner-approved decision → scientific Q1–Q18 resolution → latest progress/decision files → older context. An instruction that changes a frozen V3.2 contract still needs documented conflict and formal owner-approved CR before contract implementation. Missing exact source does not authorize reconstructed schema/API/scoring rules.

## Status

- Phase 0: DONE per handoff; historic checks 115 contract + 22 SQL, not rerun here.
- Q1–Q18 scientific research: DONE; working baseline, no default rerun.
- Charter and Phase 1 Gate: owner APPROVED.
- Learner Evidence Model: owner APPROVED with II-03 audio replay authority issue carried to exact V3.2 mapping.
- Feed and PRD: owner gave conditional **APPROVE AFTER FIX**; the stated contradiction and missing authority precedence are now corrected in the revised text. No separate owner review of the revised wording has yet been recorded.
- Phase 1 runnable foundation: ACTIVE, gate NOT PASSED. Exact V3.2 spec/checks and latest repo unavailable in current handoff/Library; SDK/database/dependencies unavailable locally for runtime proof. This is a localized blocker, not an approved change request.
- Phase 2+ and final mastery/risk/recommendation weights: DEFERRED.

## Corrected Q9 rule

Two unaided correct *first* responses on two distinct item revisions in the same objective/current task band, including one independent Check, may offer at most one next-band challenge within that objective. One success permits current-band Transfer, never step-up. Hints, retries, same-stem variants, missing Check conditions and previews cannot satisfy the predicate. A challenge does not establish mastery, raise level or unlock prerequisites. Numeric threshold=2 is an MVP hypothesis, versioned/configurable.

## II-03 audio replay

Practice playback can be flexible; Check UI defaults to offer at most two plays (hypothesis). Client playback observations can be delayed, absent or self-reported and cannot define canonical score or certify the real number of listens. The backend scores the answer independently and records offered condition, client report and quality/missingness separately. A captured client report may inform provisional low-stakes scheduling only. Exact command/telemetry/assessment mapping awaits original V3.2. No proven contract conflict or CR yet.

## Next work

Obtain the exact V3.2 source and latest repo, fill compatibility matrix with rule IDs, resolve II-03, rerun original checks, boot API/worker/Flutter/PostgreSQL/storage, execute integration/concurrency/security/CI harness and then rerun `PHASE_1_GATE.md`. Do not call Phase 1 DONE before that evidence exists. 'Mingo' is still a working label, not a frozen product name.
