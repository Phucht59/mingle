# UX Requirement Traceability

| PRD | Requirement | Primary screens | Components | QA cases |
| --- | --- | --- | --- | --- |
| PRD-01 | Finite objective-based cycle with clear closure | L-020,L-021,L-022,L-023,L-024,L-025,L-026,L-027,L-032 | C-007 | QA-LRN-001,QA-LRN-002,QA-LRN-012,QA-LRN-021 |
| PRD-02 | First response preserved; guided retry in practice | L-024,L-029 | C-003,C-005 | QA-LRN-006,QA-LRN-007 |
| PRD-03 | Typed hints; assisted != unaided; no pre-submit hint in Check | L-024,L-027,L-030 | C-006 | QA-LRN-008,QA-LRN-013 |
| PRD-04 | Skip logged; not completion/mastery | L-022,L-024,L-031 | C-005 | QA-LRN-009,QA-BIZ-003 |
| PRD-05 | Listening replay support and assessment context | L-005,L-023,L-027 | C-012 | QA-LRN-014,QA-LRN-023,QA-BIZ-005 |
| PRD-06 | Vocabulary/grammar learning sequence | L-023,L-024,L-025,L-027 | C-004 | QA-LRN-004,QA-LRN-005,QA-LRN-022 |
| PRD-07 | Bounded step-up challenge | L-010,L-041 | C-008,C-011 | QA-BIZ-006 |
| PRD-08 | Learner focus with bounded due/prerequisite insertion | L-010,L-021,L-022,L-041 | C-008 | QA-BIZ-007 |
| PRD-09 | Optional short placement; provisional result | L-004,L-005,L-006 | C-007 | QA-LRN-015,QA-LRN-016 |
| PRD-10 | Optional goal; qualitative profile/evidence | L-003,L-050,L-051,L-052 | C-010 | QA-LRN-017,QA-BIZ-008 |
| PRD-11 | Daily target/streak distinct from mastery | L-010,L-050 | C-010 | QA-BIZ-009 |
| PRD-12 | Meaningful rewards only | L-032,L-050 | C-010 | QA-BIZ-010 |
| PRD-13 | Course map, locked preview, evidence-backed reason | L-010,L-040,L-041,L-042 | C-008,C-011 | QA-LRN-018,QA-BIZ-011 |
| PRD-14 | Licensed immutable content and revision pinning | S-030,S-033,S-035,S-036,S-037,L-041 | C-015,C-016 | QA-STF-006,QA-STF-007,QA-STF-011,QA-BIZ-012 |
| PRD-15 | Command/telemetry/lifecycle separation; offline idempotent/time semantics | L-011,L-012,L-060,L-061,S-050 | C-009,C-014 | QA-OFF-001,QA-OFF-002,QA-OFF-004,QA-OFF-007,QA-BIZ-013 |
| PRD-16 | Usable deterministic fallback with ML/recommendation disabled | L-010,L-020,L-063 | C-008,C-013 | QA-LRN-019,QA-BIZ-014 |

All 16 MVP PRD requirements have an explicit UX surface and QA reference. Exact backend/API field semantics remain contract-driven and are not redefined here.


## Rework R1 fine-grained coverage

`SCREEN_STATE_QA_TRACEABILITY.csv` / `17_SCREEN_STATE_QA_TRACEABILITY.md` provide the canonical Screen ID → State → Rule → QA Case chain. This closes the earlier coarse traceability gap; QA evidence is populated only after execution.
