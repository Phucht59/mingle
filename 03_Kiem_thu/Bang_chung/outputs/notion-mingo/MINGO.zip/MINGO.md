# MINGO

Adaptive Language Learning & Early Intervention Platform

> **Phase 1 · Nền tảng triển khai**
> Tập trung đưa baseline V3.2 vào repo và chứng minh hệ thống chạy thật.

## Không gian làm việc

[Công việc](MINGO/Cong%20viec.md) — Task, roadmap và thứ tự thực hiện.

[Sản phẩm](MINGO/San%20pham.md) — Nghiệp vụ, nguyên tắc và quyết định.

[Kiểm soát](MINGO/Kiem%20soat.md) — Vấn đề, thay đổi và bằng chứng.

---

[Cách làm việc](MINGO/Cach%20lam%20viec.md) · [Nhật ký](MINGO/Nhat%20ky.md)

Nguồn khởi tạo: Manage Project.xlsx · 27/09/2026.
