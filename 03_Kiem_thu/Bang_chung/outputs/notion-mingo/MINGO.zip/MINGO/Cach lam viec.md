# Cách làm việc

## Cập nhật một task

1. Chọn trạng thái.
2. Điền người phụ trách, người kiểm tra và hạn khi đã thống nhất.
3. Ghi việc tiếp theo và cập nhật ngày.
4. Trước khi đánh XONG, đối chiếu **PASS khi** và thêm bằng chứng phù hợp.

Giữ mô tả công việc gốc; ghi tiến độ vào **Việc tiếp theo** và **Ghi chú**.

## Năm quy tắc

**1. Không tự sửa nội dung đã chốt.**

Muốn đổi kiến trúc/business rule đã khóa → tạo Đề nghị thay đổi (Change Request).

**2. Không đánh XONG chỉ vì có code.**

XONG phải có bằng chứng phù hợp: test, runtime, CI hoặc review theo gate.

**3. Phase 2 chưa được bắt đầu chính thức.**

Chỉ đủ điều kiện khi toàn bộ task bắt buộc của Phase 1 XONG.

**4. Task là nguồn trạng thái hằng ngày.**

Cập nhật trạng thái tại Task; tránh duy trì một checklist trạng thái thứ hai.

**5. Không ghi mật khẩu/token vào file.**

Chỉ ghi tên biến môi trường hoặc nơi lưu secret; tuyệt đối không ghi plaintext credential.

---

## Thuật ngữ

**Phase** — Giai đoạn phát triển có mục tiêu và điều kiện hoàn thành riêng.

**Gate** — Điều kiện bắt buộc phải đạt trước khi được coi phase đã hoàn thành.

**Blocker / Bị chặn** — Vướng mắc khiến task/gate chưa thể hoàn thành.

**Evidence / Bằng chứng** — Kết quả test, log, runtime, CI, artifact hoặc review chứng minh một claim.

**Issue / Vấn đề** — Bug, lỗi runtime, thiếu tooling, thiếu credential hoặc ambiguity cần xử lý.

**Change Request / Đề nghị thay đổi** — Quy trình xin phép thay đổi nội dung đã chốt.

**V3.2** — Baseline kiến trúc + hợp đồng hệ thống của Phase 0; không phải version app.

**Telemetry** — Dữ liệu quan sát hành vi như nghe audio, mở hint, xem màn hình; không tự quyết canonical score.
