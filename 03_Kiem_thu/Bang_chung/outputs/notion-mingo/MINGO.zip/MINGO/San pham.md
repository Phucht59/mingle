# Sản phẩm

Mingo là nền tảng học ngôn ngữ thích ứng, khởi đầu với tiếng Anh. Người học đi qua các chu kỳ học ngắn (Learning Cycle) có mục tiêu học rõ ràng, hoạt động tự nhớ/truy xuất (Retrieval), phản hồi và bài kiểm tra độc lập (Check). Hệ thống lưu bằng chứng học tập theo thời gian, hỗ trợ offline, và chỉ sau khi dữ liệu sản phẩm đủ đáng tin mới bổ sung Learning Intelligence → Risk Prediction → Recommendation/Intervention. Mingo phải vẫn hoạt động được khi ML/recommendation bị tắt.

## Đọc trước khi xây

**Mingo học theo bằng chứng**

Không biến streak/click/skip thành mastery.

**Máy chủ là nguồn quyết định chính**

Client gửi hành động/dữ liệu quan sát; server quyết định điểm, tiến độ, quyền.

**Offline không được tạo dữ liệu trùng**

Command và telemetry tách riêng; retry phải idempotent.

**ML là lớp tăng cường**

Không có ML/recommendation thì sản phẩm vẫn phải học được.

---

[Luồng người học](San%20pham/Luong%20nguoi%20hoc.md)

[Luật nghiệp vụ](San%20pham/Luat%20nghiep%20vu.md)

[Quyết định đã chốt](San%20pham/Quyet%20dinh%20da%20chot.md)

[Giả thuyết cần kiểm chứng](San%20pham/Gia%20thuyet.md)

[Baseline V3.2](San%20pham/Baseline%20V3.2.md)
