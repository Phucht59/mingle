# Kiểm soát

Ghi nhận điều đang cản trở và bằng chứng đã có.

[Vấn đề](Kiem%20soat/Van%20de.csv) — Lỗi, blocker và nội dung cần làm rõ.

[Thay đổi](Kiem%20soat/Thay%20doi.md) — Đề nghị sửa nội dung đã chốt.

[Bằng chứng](Kiem%20soat/Bang%20chung.csv) — Test, runtime và CI.

## Đọc trạng thái bằng chứng

**PASS** — Có bằng chứng trong phạm vi được ghi.

**PASS LỊCH SỬ** — Kết quả trong package cũ; chưa đồng nghĩa đã chạy lại trên Mingo.

**CHỜ CHẠY** — Cần chạy lại.

**BỊ CHẶN** — Thiếu dependency để thực hiện.
