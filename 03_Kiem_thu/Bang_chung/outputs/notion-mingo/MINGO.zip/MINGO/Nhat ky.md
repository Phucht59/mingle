# Nhật ký

## V3.2

**NOTE-001 · 2026-09-26 · P1 · ĐANG LÀM**

Original completed package đã được cung cấp sau khi trước đó repo không có.

**Việc cần làm:** Import/rerun original suites.

**Liên quan:** P1-T001 / II-01

---

## Database

**NOTE-002 · 2026-09-26 · P1 · ĐANG LÀM**

Không chia DB theo phase.

**Việc cần làm:** Dùng mingo + mingo_test + role mingo_app.

**Liên quan:** Database decision
