# Công việc

Một nơi cập nhật trạng thái hằng ngày.

[Task](Cong%20viec/Task.csv)

[Roadmap](Cong%20viec/Roadmap.csv)

## Ưu tiên triển khai

1. **Import + rerun V3.2 original** — Đóng nguồn chuẩn Phase 0 trong canonical repo.

2. **PostgreSQL + migration + DB tests** — Đóng runtime backend quan trọng nhất.

3. **API readiness + Worker** — Chứng minh backend foundation chạy thật.

4. **Flutter learner + staff** — Chứng minh Android/Web chạy thật.

5. **Hosted CI** — Chứng minh clean checkout chạy được.

6. **Full clean reproduction** — Bằng chứng cuối trước khi đóng Phase 1.

## Gate Phase 1

Chỉ chuyển sang Phase 2 khi toàn bộ 12 task bắt buộc của Phase 1 đã XONG và có bằng chứng đạt tiêu chí. Tiêu chí từng việc nằm trong thuộc tính **PASS khi** của Task.

Ảnh chụp dữ liệu 27/09/2026: 0/12 task Phase 1 XONG; 1 đang làm, 3 chờ, 8 bị chặn. Gate chưa PASS. Trạng thái vận hành xem trong Task.
