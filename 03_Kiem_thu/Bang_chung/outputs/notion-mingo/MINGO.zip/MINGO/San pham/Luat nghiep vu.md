# Luật nghiệp vụ

## First response

Câu trả lời đầu tiên phải được giữ. Retry đúng sau đó không biến lịch sử thành 'đúng ngay từ đầu'.

## Hint

Đúng sau hint = đúng có hỗ trợ (assisted), không phải đúng độc lập (unaided).

## Skip

Skip được ghi lại nhưng KHÔNG phải completion, mastery hay progress.

## Check

Bài kiểm tra độc lập; không có hint trước khi submit.

## Audio replay

Telemetry ở client không chứng minh chắc chắn người dùng đã nghe bao nhiêu lần và không tự quyết điểm chuẩn.

## Content revision

Nội dung đã publish là bất biến; muốn sửa phải tạo revision mới.

## Attempt

Attempt phải pin đúng revision mà learner đã thấy lúc làm.

## Offline

Business command và telemetry đi hai luồng riêng; retry không được tạo progress hai lần.

## Mastery / Risk

Mastery và Risk là hai khái niệm khác nhau.

## Recommendation

Prediction ≠ Decision ≠ Exposure ≠ Execution ≠ Outcome.

## ML OFF

Khi ML/recommendation bị tắt, curriculum + review fallback vẫn phải tạo được chu kỳ học hợp lệ.
