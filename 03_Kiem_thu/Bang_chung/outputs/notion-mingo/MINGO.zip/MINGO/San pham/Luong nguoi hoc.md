# Luồng người học

## 01. Mở app

Người học vào Mingo; có thể chọn mục tiêu cá nhân.

## 02. Placement ngắn hoặc bỏ qua

Tạo trạng thái bắt đầu tạm thời (provisional); không ép placement dài.

## 03. Chọn mục tiêu học / chu kỳ học

Backend chọn nội dung đủ điều kiện theo curriculum, review, focus và prerequisite.

## 04. Review

Ôn đúng thứ cần ôn; không tạo infinite scroll.

## 05. Learn

Giải thích/ngữ cảnh ngắn phù hợp Vocabulary, Grammar hoặc Listening.

## 06. Retrieve

Người học phải tự nhớ/trả lời; đây là bằng chứng quan trọng.

## 07. Transfer

Dùng kiến thức trong ngữ cảnh khác.

## 08. Check

Bài kiểm tra độc lập; server là nguồn quyết định điểm chính.

## 09. Feedback + lưu evidence

Giữ đúng first response, retry, hint, skip và điều kiện assessment.

## 10. Kết thúc cycle

Có điểm dừng rõ; người học chọn tiếp tục hoặc dừng.

## 11. Tích lũy theo thời gian

Review scheduler và analytics tích lũy; intelligence/risk/recommendation đến ở phase sau.
