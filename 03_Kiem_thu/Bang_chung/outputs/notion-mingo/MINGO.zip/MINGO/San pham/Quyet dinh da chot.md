# Quyết định đã chốt

## V3.2

V3.2.0 completed baseline là source of truth của Phase 0.

## Stack

Flutter Android-first cho learner; Flutter Web cho staff; FastAPI/Python; PostgreSQL; Object Storage.

## Architecture

Modular monolith; API process + durable worker dùng cùng codebase.

## Authority

Máy chủ quyết định canonical scoring, progress và permission.

## Offline

Command queue tách telemetry queue.

## Content

Published content immutable/versioned; attempt/enrollment pin exact revision.

## Analytics time

Phân biệt event time và knowledge/availability/source capture.

## Mastery / Risk

Mastery khác Risk.

## Recommendation

Risk chỉ là input tùy chọn; ML/recommendation OFF thì app vẫn học được.

## Lifecycle

Prediction / Decision / Exposure / Execution / Outcome tách riêng.

## Hạ tầng

Không Kafka/Kubernetes/microservices/warehouse/external feature store nếu chưa có requirement/load thật.

## Database

Một Mingo: DB chính `mingo`, DB test disposable `mingo_test`, role `mingo_app`; không chia DB theo phase.

## Quản trị phase

Mỗi phase phải có deliverables + acceptance criteria + gate rồi mới qua phase sau.

## ML production

OULAD/UCI chỉ là research baseline; production model phải đánh giá bằng product data.
