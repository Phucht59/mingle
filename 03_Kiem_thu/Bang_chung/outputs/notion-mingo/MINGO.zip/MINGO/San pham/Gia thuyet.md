# Giả thuyết cần kiểm chứng

## Tên Mingo

Đang là working name; chưa freeze final brand.

## ~5 phút / cycle

UX hypothesis; có thể đổi sau đo/pilot.

## 1 retry

Retry count là hypothesis; việc giữ first response là nguyên tắc mạnh hơn.

## 2 lần nghe trong Check

Hypothesis; server authority mới là invariant.

## Placement 6–9 câu

Thiết kế provisional; không phải CEFR cut score cuối.

## Step-up threshold

2 evidence + 1 Check + max 1 challenge là policy hypothesis.

## Final mastery formula

Chờ Phase 9 — Learning Intelligence.

## Final risk label/model/weights

Chờ Phase 10 + product data.

## Recommendation ranking weights

Chờ Phase 11.
