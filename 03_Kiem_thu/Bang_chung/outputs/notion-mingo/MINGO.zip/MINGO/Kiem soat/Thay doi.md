# Thay đổi

Chỉ tạo đề nghị khi muốn đổi nội dung đã chốt. Hiện chưa có Change Request trong file nguồn.

## Mẫu đề nghị

Sao chép mẫu này cho mỗi đề nghị mới.

- **CR ID:**
- **Ngày:**
- **Người đề nghị:**
- **Nội dung muốn đổi:**
- **Lý do:**
- **Ảnh hưởng:**
- **Kế hoạch test / migration:**
- **Trạng thái:** NHÁP
- **Người duyệt:**

## Luồng duyệt

NHÁP → ĐANG XEM → ĐÃ DUYỆT → ĐÃ TRIỂN KHAI

Trường hợp không tiếp tục: TỪ CHỐI hoặc HỦY.
