# Findings — before/after targeted closure

Existing IDs and prior FIXED/PASS dispositions are preserved; no new distinct issue requiring AUD-013 was confirmed. Candidate synchronization is not canonical application.

## AUD-001

**ID:** AUD-001

**Severity:** BLOCKER

**Status:** OPEN

**Area:** Required BA evidence

**Artifact:** Mingo GD1 — Quản lý Phân tích Nghiệp vụ.xlsx (absent)

**Location:** C:/Mingo entire tree including 02_Tai_lieu_du_an, 99_Luu_tru, outputs, .local; expected canonical BA zone

**Observed:** NOT FOUND after recursive hidden/ignored search: 116 Excel paths, 12 unique contents; every plausible candidate inspected; no expected BA sheet family or exact hash anchor.

**Expected:** Inspect actual approved BA workbook, including all P0/P1 chains and known candidates.

**Evidence:** workbook_discovery.json; WORKBOOK_DISCOVERY.md; artifact_candidates.txt

**Source of truth:** User source hierarchy Levels 1–3

**Impact:** Cannot certify workbook consistency or close GD1 internal gate.

**Recommended action:** Bring the actual workbook into the audit boundary and rerun the workbook/RTM checks; do not fabricate a replacement.

**Change Request required:** NO

**Gate blocking:** YES

**Before fix:** NOT FOUND. Only a seven-sheet project-management workbook and dated Phase2 QA controls are available. N-06→WF-10, WBS 1.11, requirement priorities and workbook semantics cannot be verified. Previous status=OPEN

**After fix:** No fabrication/candidate workbook. Known A–E observations UNKNOWN. AUD-001 not closed.

## AUD-002

**ID:** AUD-002

**Severity:** MEDIUM

**Status:** FIXED

**Area:** Snapshot continuity

**Artifact:** MINGO_PROJECT_PROGRESS_SNAPSHOT_2026-10-04.md

**Location:** Workspace inventory; PROJECT_PROGRESS_SNAPSHOT.md

**Observed:** Requested dated snapshot NOT FOUND. Available snapshot is a navigation document, referencing 2026-10-02 authority and unsigned Phase2 gate. The new user instruction records GD1 conclusion approval on 2026-10-04.

**Expected:** Preserve old history, record approved GD1 direction and distinguish business GD1 from engineering Phase1.

**Evidence:** PROJECT_PROGRESS_SNAPSHOT.md paragraphs 1–2; PROJECT_STATE.md phase table; user approval record

**Source of truth:** User approval dated 2026-10-04; V3.2

**Impact:** Cross-chat continuation can confuse internal BA approval, foundation closure and human design acceptance.

**Recommended action:** Create a new dated audit snapshot with explicit source limitation and phase distinction.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Requested dated snapshot NOT FOUND. Available snapshot is a navigation document, referencing 2026-10-02 authority and unsigned Phase2 gate. The new user instruction records GD1 conclusion approval on 2026-10-04. Previous status=FIXED

**After fix:** Prior disposition retained; outside targeted scope. Created a new dated continuation snapshot; requested 2026-10-04 source remains NOT FOUND and no history is fabricated.

## AUD-003

**ID:** AUD-003

**Severity:** HIGH

**Status:** OPEN

**Area:** Traceability and priority

**Artifact:** MVP_PRD.md; PRD_TRACEABILITY_V2.csv; SCREEN_STATE_TRACEABILITY.csv

**Location:** All PRD-01..16; CSV headers and rows 2–17

**Observed:** 16 current repo requirement statements/AC inspected; all actual priorities UNKNOWN. Current explicit screen/QA mappings have zero dangling references; complete formal workbook Need/BR/Trigger/UC/WF/AC/Test chains not available.

**Expected:** A reviewable complete requirement→rule→trigger→flow→screen/state→acceptance/test chain, with accountable priority and justified support/future surfaces.

**Evidence:** requirement_inventory_before.json; semantic_trace_current.json; structural_audit_current.json; TRACEABILITY_AUDIT.md; ORPHAN_REGISTER.md

**Source of truth:** User GD1 capability Definition of Done; V3.2 compatibility matrix

**Impact:** P0-first completeness and orphan business-rule coverage cannot be certified across the missing workbook.

**Recommended action:** Supply semantic trace audit for all 16 repo PRDs; reconcile it with actual workbook BR/UC/Trigger IDs and priorities. Do not infer requirement priority from QA priority.

**Change Request required:** NO

**Gate blocking:** YES

**Before fix:** 16 PRDs map to existing screens/QA and 175 states, but PRD trace has no explicit BR/Trigger/UC relations or requirement P0/P1 field. Journeys provide semantic coverage for many rows. 27 routes lack a direct PRD mapping; several have clear inherited support/future rationale, so this is not 27 unauthorized features. Previous status=OPEN

**After fix:** Source-cited repo semantic table/orphan register and safe repair plan supplied. Fingerprint ordering does not set priority. Candidate trace does not close actual workbook chain.

## AUD-004

**ID:** AUD-004

**Severity:** HIGH

**Status:** FIXED

**Area:** Product actors and permission intent

**Artifact:** MVP_PRD.md; V3.2 docs/07_SECURITY_PERMISSION_V3.md; Staff journeys

**Location:** Actors paragraph; Object scopes; J-S01/J-S03/J-S06

**Observed:** Learner, assigned instructor/advisor, content admin, platform admin and worker scopes exist. No complete canonical product model distinguishes Author, Reviewer, Publisher/Operator, Staff umbrella, conditional Advisor and FUTURE Guardian. A staff review fixture is not permission design.

**Expected:** Business role boundaries and scope classification without inventing permission implementation or separation-of-duties rules.

**Evidence:** V3.2 docs/07 object scopes; PHASE_2_SPEC.json staff entries; no actor register found in active product docs

**Source of truth:** V3.2 security boundary; approved GD1 closure scope

**Impact:** Content/support operations cannot be handed off with a complete role intent model.

**Recommended action:** Record existing approved role intent and explicit undecided assignment/segregation questions; reconcile with workbook once available.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Learner, assigned instructor/advisor, content admin, platform admin and worker scopes exist. No complete canonical product model distinguishes Author, Reviewer, Publisher/Operator, Staff umbrella, conditional Advisor and FUTURE Guardian. A staff review fixture is not permission design. Previous status=FIXED

**After fix:** Prior disposition retained; outside targeted scope. Approved role intent consolidated in GD1_INTERNAL_BA_CLOSURE_NOTES_20261005.md; detailed role assignment remains explicitly undecided. Missing-workbook verification remains AUD-001.

## AUD-005

**ID:** AUD-005

**Severity:** HIGH

**Status:** OPEN

**Area:** Account lifecycle BA

**Artifact:** MVP_PRD.md; learner journeys; roadmap

**Location:** PRD-01..16; J-L01..15; /reauth L-064; engineering Phase3

**Observed:** Q3 definitively approves Guest/Account Gate, Email required supported/Google target/Facebook future and valid intended return. Full minimum registration/logout/session/failure/recovery/device/privacy request BA chain remains unavailable; actual P0 dependency completeness UNKNOWN.

**Expected:** Trace approved gate and every necessary minimum lifecycle capability, explicitly scoped/deferred or narrowly escalated without invented policies.

**Evidence:** PO_TARGETED_REQUEST.txt Q3; V3.2 docs07/docs10; account_matrix_current.json; ACCOUNT_LIFECYCLE_CANDIDATE.md; candidate_docs/CHANGE_REQUESTS.patch

**Source of truth:** User account capability audit; V3.2 identity/object/deletion contracts

**Impact:** Identity and data-rights behavior remains insufficiently specified for a GD1 business handoff.

**Recommended action:** Inspect actual workbook first; reconcile approved Q3 gate and source-derived AC, resolve minimum lifecycle/necessary P0 gaps. Exact policy decisions may defer to GĐ4 with owner; do not request account inclusion again.

**Change Request required:** NO for approved PO synchronization; conditional DRAFT only if a necessary new unapproved business policy is proven after source reconciliation

**Gate blocking:** YES

**Before fix:** No canonical BA flow and acceptance chain for signup/login/logout/recovery/session/device change/account state/deletion/export. Profile/preferences and reauth design exist. Auth implementation is legitimately held for Phase3, which does not establish business requirements or MVP scope. Previous status=OPEN

**After fix:** Approved gate/method/destination inclusion synchronized in candidate; 17-capability account matrix and 8 source-derived spec-only AC supplied. Broad CR-GD1-001 superseded as not required for approved semantics in candidate. AUD-005 remains OPEN; runtime auth not implemented.

## AUD-006

**ID:** AUD-006

**Severity:** MEDIUM

**Status:** FIXED

**Area:** NFR/privacy consolidation

**Artifact:** Telemetry purpose register; Evidence model; V3.2 retention controls

**Location:** Collection gate/lifecycle; Evidence model §5; V3.2 docs/10

**Observed:** Telemetry purpose/minimization and delete/restore races are specified; collection disabled and TTL/access approval pending. Active artifacts do not record Law 91/2025/QH15 or Decree 356/2025/NĐ-CP. No obsolete Decree13 primary reference found in inspected active docs. NFR rules are scattered, rather than a GD1 checklist.

**Expected:** Record verified 2026 legal source context and purpose→collection→access→use→retention→deletion/export→audit intent; no invented legal TTL/SLA.

**Evidence:** Telemetry register; Evidence model §5; official government law/decree metadata, both effective 2026-01-01

**Source of truth:** V3.2; recorded project privacy baseline; official government metadata

**Impact:** Pre-pilot governance dependency is difficult to track. No observed unauthorized collection or proven blocking privacy contradiction.

**Recommended action:** Add source-backed privacy/NFR closure notes and keep numeric retention/SLO and collection approval pending.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Telemetry purpose/minimization and delete/restore races are specified; collection disabled and TTL/access approval pending. Active artifacts do not record Law 91/2025/QH15 or Decree 356/2025/NĐ-CP. No obsolete Decree13 primary reference found in inspected active docs. NFR rules are scattered, rather than a GD1 checklist. Previous status=FIXED

**After fix:** Prior disposition retained; outside targeted scope. Source-backed legal-context metadata, NFR checklist and governance intent consolidated. TTL/SLO and collection approval remain later prerequisites, not completed runtime.

## AUD-007

**ID:** AUD-007

**Severity:** MEDIUM

**Status:** OPEN

**Area:** Stale management workbook

**Artifact:** Quan_ly_du_an_Mingo.xlsx

**Location:** 00_BAT_DAU!B17; 01_TONG_QUAN!B7; 02_SAN_PHAM!B86; 03_ROADMAP!F6; 04_CONG_VIEC!F5:F7; 05_VAN_DE_THAY_DOI!C6:D6; 06_BANG_CHUNG!E8:E9

**Observed:** Workbook calls Phase1 current, Phase2 not started, original import/rerun pending. Actual original source and reruns exist and PROJECT_STATE says Phase2 review pending. This is a different workbook from requested GD1 BA artifact.

**Expected:** Consistent dated authority or clearly historical classification; task evidence drives statuses.

**Evidence:** Read-only cell extraction with source hash; PROJECT_STATE current table; fresh 115+22 run

**Source of truth:** V3.2 executed evidence; scoped PROJECT_STATE; preserved historical gate evidence

**Impact:** A reader may act on stale blocker/status. Not evidence of premature GD1 DONE.

**Recommended action:** Provide exact correction plan for this workbook separately; do not substitute it for BA workbook or blindly mark all foundation tasks done.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Workbook calls Phase1 current, Phase2 not started, original import/rerun pending. Actual original source and reruns exist and PROJECT_STATE says Phase2 review pending. This is a different workbook from requested GD1 BA artifact. Previous status=OPEN

**After fix:** Prior disposition retained; outside targeted scope. Unchanged; see recommended action and the scoped audit limits.

## AUD-008

**ID:** AUD-008

**Severity:** HIGH

**Status:** FIXED

**Area:** Current documentation status drift

**Artifact:** PRODUCT_CHARTER.md; MVP_PRD.md; LEARNER_EVIDENCE_MODEL.md; DECISION_REGISTER.md

**Location:** Charter opening and acceptance; PRD final paragraph/PRD-10 status; Evidence model opening/footer; current Decision register

**Observed:** Charter says exact V3.2 pending and brand not frozen; PRD says exact V3.2 unavailable/pending; Evidence footer requires completing a matrix already completed 2026-09-26. PRD-10 still labels optional goal principle as hypothesis. No scoped 2026-10-04 GD1 approval record.

**Expected:** Current docs acknowledge supplied/verified originals and approved optional/editable goal principle; exact goal categories stay hypothesis; GD1 approval is not Phase2 human signoff or customer validation.

**Evidence:** Charter first/final paragraphs; PRD-10 and Out of scope; compatibility matrix; user approval record

**Source of truth:** Verified V3.2; user 2026-10-04 approval

**Impact:** Implementation may treat resolved authority mapping as blocked or infer approval beyond its scope.

**Recommended action:** Correct stale status/terminology only, preserving versioned policies and historical decisions.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Charter says exact V3.2 pending and brand not frozen; PRD says exact V3.2 unavailable/pending; Evidence footer requires completing a matrix already completed 2026-09-26. PRD-10 still labels optional goal principle as hypothesis. No scoped 2026-10-04 GD1 approval record. Previous status=FIXED

**After fix:** Prior disposition retained; outside targeted scope. Stale availability/mapping/status wording corrected; approved optional goal principle distinguished from hypothesis categories; scoped approval recorded.

## AUD-009

**ID:** AUD-009

**Severity:** MEDIUM

**Status:** OPEN

**Area:** Optional goal presentation drift

**Artifact:** fixtures.dart; learner.dart; J-L01

**Location:** ReviewPreferences.goal line53; L-003 content lines383–410

**Observed:** Goal initializes to Giao tiếp hằng ngày, is non-null, and L-003 only offers Continue; no explicit skip/missing-goal state. Welcome can bypass the whole flow, but the default preference still exists. The proposed optional goal is not faithfully represented in this fixture.

**Expected:** Optional explicit intent remains distinct from missing/skipped intent; editing remains allowed and never creates evidence or bypasses prerequisites.

**Evidence:** Source code and J-L01; PRD-10; supplied approved goal decision

**Source of truth:** Approved first-use direction; V3.2 evidence/eligibility boundaries

**Impact:** Preview may suggest a goal selected by the learner when it was a default. No production collection exists.

**Recommended action:** Record candidate presentation behavior CR; retain code and goldens until authorized targeted implementation/retest.

**Change Request required:** YES

**Gate blocking:** NO

**Before fix:** Goal initializes to Giao tiếp hằng ngày, is non-null, and L-003 only offers Continue; no explicit skip/missing-goal state. Welcome can bypass the whole flow, but the default preference still exists. The proposed optional goal is not faithfully represented in this fixture. Previous status=OPEN

**After fix:** Prior disposition retained; outside targeted scope. Unchanged; see recommended action and the scoped audit limits.

## AUD-010

**ID:** AUD-010

**Severity:** MEDIUM

**Status:** OPEN

**Area:** First Home/resume explanation drift

**Artifact:** learner.dart; fixtures.dart; PHASE_2_SPEC.json

**Location:** L-010 content lines447–485; nextLessonReason lines89–98; Home actions/rules

**Observed:** Home passes due=true for ordinary first-use state and never supplies hasResume to its helper; primary action is always Start. Helper unit tests cover hasResume but the Home wiring does not. Stateless sample mode is disclosed.

**Expected:** First-use explanation reflects missing/provisional evidence; returning valid unfinished work has resume semantics. Exact ranking remains hypothesis unless separately approved.

**Evidence:** learner.dart nextLessonReason call; helper/test; J-L01/J-L12; Home spec reason/actions

**Source of truth:** Approved truthful reason/resume direction; no new ranking invariant

**Impact:** UI tests can pass while a named business scenario is not represented. Does not prove broken durable production sync.

**Recommended action:** Add to candidate presentation CR and require first-use/returning/resume scenario evidence; do not silently freeze candidate priority.

**Change Request required:** YES

**Gate blocking:** NO

**Before fix:** Home passes due=true for ordinary first-use state and never supplies hasResume to its helper; primary action is always Start. Helper unit tests cover hasResume but the Home wiring does not. Stateless sample mode is disclosed. Previous status=OPEN

**After fix:** Prior disposition retained; outside targeted scope. Unchanged; see recommended action and the scoped audit limits.

## AUD-011

**ID:** AUD-011

**Severity:** INFO

**Status:** PASS

**Area:** Validation and runtime boundaries

**Artifact:** Initial wedge plan; V3.2 docs/12; API and UI sources

**Location:** E0 status; implementation acceptance plan; api.py routes; ReviewLabel/fixtures

**Observed:** Customer discovery and efficacy remain pending; no positive customer/market validation claim found in inspected active sources. API exposes health only; Flutter sample logic is labelled presentation. Full native domain/offline/auth/restore scenarios not run.

**Expected:** Customer validation remains VALIDATION DEBT; contract/schema/UI PASS never becomes production/runtime/efficacy PASS.

**Evidence:** Initial wedge plan; docs/12 first paragraph; source API/UI; current phase state

**Source of truth:** User evidence hierarchy and V3.2

**Impact:** No defect in separating evidence layers; later gates remain necessary.

**Recommended action:** Preserve boundary in report, debt register and snapshot.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Customer discovery and efficacy remain pending; no positive customer/market validation claim found in inspected active sources. API exposes health only; Flutter sample logic is labelled presentation. Full native domain/offline/auth/restore scenarios not run. Previous status=PASS

**After fix:** Prior disposition retained; outside targeted scope. Unchanged; see recommended action and the scoped audit limits.

## AUD-012

**ID:** AUD-012

**Severity:** INFO

**Status:** PASS

**Area:** Repository identity

**Artifact:** Git origin and GitHub repository metadata

**Location:** origin Phucht59/mingo vs requested Phucht59/mingle

**Observed:** Two requested URL spellings resolve through GitHub API to the same repository ID 1388925852/full_name Phucht59/mingle. ls-remote HEAD equals local a112f762ab08f6fa688cc4857b21d95d1055ab5c. Working tree is dirty; remote commit is not this full candidate.

**Expected:** Use verified repo identity and disclose dirty source boundary.

**Evidence:** GitHub API read-only responses; git ls-remote; git_identity.json; git_status_before.txt

**Source of truth:** Actual repository metadata and Git state

**Impact:** Name mismatch resolved; dirty candidate is still not hosted CI evidence.

**Recommended action:** Record both URLs and common identity; do not switch/reset/commit/push.

**Change Request required:** NO

**Gate blocking:** NO

**Before fix:** Two requested URL spellings resolve through GitHub API to the same repository ID 1388925852/full_name Phucht59/mingle. ls-remote HEAD equals local a112f762ab08f6fa688cc4857b21d95d1055ab5c. Working tree is dirty; remote commit is not this full candidate. Previous status=PASS

**After fix:** Prior disposition retained; outside targeted scope. Unchanged; see recommended action and the scoped audit limits.
